Installer l'application localement pour la faire fonctionner
<?php
exit;
// Connexion
$host = 'localhost';
$username = 'mboudrea';
$password = base64_decode('ZWxlZmFu');
$dbname = 'mboudrea_monde2';
$charset = 'utf8';
$dsn = "mysql:host=$host;charset=$charset;";
$db = new PDO($dsn, $username, $password);
$rep = $db->exec('USE '.$dbname.';');
if (!$rep) {
	$db->exec('CREATE DATABASE IF NOT EXISTS '.$dbname.' DEFAULT CHARSET utf8;');
	$db->exec('USE '.$dbname.';');
	$db->exec(file_get_contents("monde.sql"));
}
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Composition du SQL
$SQL = "SELECT id, nom2 FROM pays ORDER BY nom2;";
$stmt = $db->prepare($SQL);	
$stmt->bindColumn("id", $id);
$stmt->bindColumn("nom2", $nom2);

// Exécution de la requête
try {
	$stmt->execute();
} catch (PDOException $e) {
	throw new Exception($e->getMessage());
}

// Composition de l'affichage
$tblPays = '';
$tblPays .= '<table class="liste">';
$tblPays .= '<col class="drapeau" />';
$tblPays .= '<col class="nom" />';
$tblPays .= '<col class="options" />';
$tblPays .= '<thead>';
$tblPays .= '<tr>';
$tblPays .= '<th>&nbsp;</th>';
$tblPays .= '<th>Nom</th>';
$tblPays .= '<th>Options</th>';
$tblPays .= '</thead>';
$tblPays .= '<tbody>';
if ($stmt->rowCount() == 0) {
	$tblPays .= '<tr>';
	$tblPays .= '<td colspan="3">Aucun pays trouvé</td>';
	$tblPays .= '</tr>';
} else {
	while ($stmt->fetch()) {
		$tblPays .= '<tr>';
		$tblPays .= '<td><a href="details.php?id=' . $id . '"><img class="drapeau" src="http://openiconlibrary.sourceforge.net/gallery2/Flags/ISO/png/32x32/flag-'.strtolower($id).'.png" alt="" height="16"/></a></td>';
		$tblPays .= '<td><a href="details.php?id=' . $id . '">' . $nom2 . '</a></td>';
		$tblPays .= '<td class="options">';
		$tblPays .= '<a href="details.php?id=' . $id . '">Détails</a>';
		$tblPays .= '<a href="modifier.php?id=' . $id . '">Modifier</a>';
		$tblPays .= '<a href="supprimer.php?id=' . $id . '">Supprimer</a>';
		$tblPays .= '</td>';
		$tblPays .= '</tr>';
	}
}
$tblPays .= '</tbody>';
$tblPays .= '</table>';
?>
<html>
	<head>
		<title>Affichage des pays</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="reset.css" />
		<link rel="stylesheet" type="text/css" href="monde.css" />
	</head>

	<body>
		<div id="interface">
			<header><h1>Mes pays</h1></header>
			<nav class="principal">
				<ul>
					<li><a href="index.php">Accueil</a></li>
					<li><a href="details.php?id=alea">Un pays aléatoire</a></li>
					<li><a href="ajouter.php">Ajouter un pays</a></li>
				</ul>
			</nav>
			<div class="contenu">
				<h2>Liste des pays</h2>
				<?php echo $tblPays; ?>
			</div>
			<footer>&copy;</footer>
		</div>
	</body>
</html>
